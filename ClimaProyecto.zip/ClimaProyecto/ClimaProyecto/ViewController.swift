//
//  ViewController.swift
//  ClimaProyecto
//
//  Created by Macbook on 4/1/19.
//  Copyright © 2019 Theranos. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var Ciudad: UILabel!
    @IBOutlet weak var climaa: UILabel!
    @IBOutlet weak var Imagen: UIImageView!
    @IBOutlet weak var temp: UILabel!
    @IBOutlet weak var fecha: UILabel!
    
    var Clima:[String] = []
    
    override func viewDidLoad() {
    super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        getWeather()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Clima.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Celda", for: indexPath)
        cell.textLabel?.text = Clima[indexPath.row]
        return cell
    }
    func getWeather(){
        
        let url = URL(string: "https://api.weatherbit.io/v2.0/current?city=Cuernavaca,Mx&key=96ba6dd0344e4f83af551a6c92cd1136")
        
        let jsonDecoder = JSONDecoder()
        
        let tarea = URLSession.shared.dataTask(with: url!){ (data, response, error) in
            if let data = data, let results = try? jsonDecoder.decode(Results.self, from: data){
            for data in results.data{
                print(data.temp)
                self.Clima.append(temperatura.climaTemperatura)
            }
                DispatchQueue.main.async {
                    //self.temp.text = "Temperatura de Cuernavaca es: \(Clima[climaTe])"
                }
        }
        
        
    }
    
    }
    
}


