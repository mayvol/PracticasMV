//
//  ViewController.swift
//  ClimaProyecto
//
//  Created by Macbook on 4/1/19.
//  Copyright © 2019 Theranos. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var fondoClimaView: UIImageView!
    @IBOutlet weak var Ciudad: UILabel!
    @IBOutlet weak var climaa: UILabel!
    @IBOutlet weak var Imagen: UIImageView!
    @IBOutlet weak var temp: UILabel!
    @IBOutlet weak var fecha: UILabel!
    @IBOutlet weak var Zona: UILabel!
    
    var Clima:Data!

    
    override func viewDidLoad() {
    super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        getWeather()
    }

    func getWeather(){
        

        let url = URL(string: "https://api.weatherbit.io/v2.0/current?city=Mexico,Mx&key=96ba6dd0344e4f83af551a6c92cd1136")
        
        let jsonDecoder = JSONDecoder()
        
        let tarea = URLSession.shared.dataTask(with: url!){ (data, response, error) in
          
            if let data = data, let results = try? jsonDecoder.decode(Results.self, from: data){
                print("Hola")
            for dataKey in results.data{
                print(dataKey.temp)
                
                DispatchQueue.main.async {
                    self.Zona.text = dataKey.timezone
                    self.fecha.text = String(dataKey.datetime)
                    self.Ciudad.text = dataKey.city_name
                    self.climaa.text = dataKey.weather.description
                    self.temp.text = "La temperatura es: \(dataKey.temp)" + " ºC"
                    self.elegirImagen(icon: dataKey.weather.icon)
                    self.elegirFondo(temp: dataKey.temp)
                }
            }
        }
        
        
    }
        tarea.resume()
    
    }
    func elegirImagen(icon: String){
        let path  = "https://www.weatherbit.io/static/img/icons/" + icon + ".png"//Crear una nueva cadena (nuevo url)
        let url = URL(string: path)
        let tarea = URLSession.shared.dataTask(with: url!) { (data, response, error) in
            if let dat = data{
                let image = UIImage(data: dat)
                DispatchQueue.main.async {
                    self.Imagen.image = image
                }
            }
        }
        tarea.resume()
        
    }
    func elegirFondo(temp: Double){
        
         if (temp == 0){
         fondoClimaView.image = UIImage (named: "iceWallpaper")
         }else if (temp == 0 || temp <= 10){
         fondoClimaView.image = UIImage (named: "frio")
         }else if (temp == 11 || temp <= 20){
         print("hoooola")
         //self.fondoClimaView.image = UIImage (named: "sun2")
         }else if (temp == 21 || temp <= 25){
         fondoClimaView.image = UIImage (named: "sunWallpaper")
         }else if (temp > 25){
         fondoClimaView.image = UIImage (named: "nublado")
        }
    }
}

